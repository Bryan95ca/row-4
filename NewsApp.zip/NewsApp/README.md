Open up the the webpage and Scroll through the news!

You can choose which outlets you like and if you either want to read international or national news.

The selection Bar on the left has a whole other news outlets.

You can also login and Create an Account which will be added to a firebase system.

You can also go into the "blog" Secition and post comments and articles which will then be uploaded onto Firebase with your own specific UID attached to the post.