const express = require('express');
const router = express.Router();
const mongodb = require('mongodb');
 
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
 
router.get('/employeelist', function(req, res){
//mongo db server
  const MongoClient = mongodb.MongoClient;

  const url = 'mongodb://localhost:27017/shopsite';
 
  // Connect to the server
  MongoClient.connect(url, function (err, db) {
  if (err) {
    console.log('Unable to connect..', err);
  } else {
    // We are connected
    console.log('Connection established..', url);
 
    // Get collection in DB
    const collection = db.collection('employee');
 
    // Find Employee
    collection.find({}).toArray(function (err, result) {
      if (err) {
        res.send(err);
      } else if (result.length) {
        res.render('employeelist',{
 
          // Return to Jade..
          "employeelist" : result
        });
      } else {
        res.send('No documents found');
      }

      db.close();
    });
  }
  });
});

router.get('/newemployee', function(req, res){
    res.render('newemployee', {title: 'Add employee' });
});
 
router.post('/addemployee', function(req, res){
 
    // Mongo Client
    const MongoClient = mongodb.MongoClient;
 
    // MongoDB host
    const url = 'mongodb://localhost:27017/shopsite';
 
    // Connection
    MongoClient.connect(url, function(err, db){
      if (err) {
        console.log('Server: Error:', err);
      } else {
        console.log('Server: Connected!');
 
        // document of collection
        const collection = db.collection('employee');
 
        let employee = {employee: req.body.employee, street: req.body.street,
          city: req.body.city, state: req.body.state, sex: req.body.sex,
          gpa: req.body.gpa};
        //insert 
        collection.insert([employee], function (err, result){
          if (err) {
            console.log(err);
          } else {
          //redirects back to url: /employee
            res.redirect("employee");
          }
 
          db.close();
        });
 
      }
    });
 
  });
 
module.exports = router;