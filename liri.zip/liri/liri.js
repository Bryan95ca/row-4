
// node liri.js [ action ] [ query - optional ]
let action = process.argv[2];
let query = process.argv[3];

const spotifyThisSong = function(trackQuery) {
	// Spotify Npm
	let spotify = require('spotify');

	// if no trackQuery is passed in, then we will be querying for this particular song
	if(trackQuery === undefined) {
		trackQuery = "kids-bop";
	}

	spotify.search({ type: 'track', query: trackQuery }, function(error, data) {
	    if(error) { // if error
	        console.log('Error occurred: ' + error);
	    } else { // error
            //multiple artist
            
				for(let x = 0; x < data.tracks.items[0].artists.length; x++) {
					if(x === 0) {
						console.log("Artist(s):    " + data.tracks.items[0].artists[x].name);
					} else {
						console.log("              " + data.tracks.items[0].artists[x].name);
					}
				}
				console.log("Song:         " + data.tracks.items[0].name);
				console.log("Preview Link: " + data.tracks.items[0].preview_url);
				console.log("Album:        " + data.tracks.items[0].album.name);
	    }
	 
	 		
	});
}

let movieThis = function(movieQuery) {
	//npm module
	let request = require("request");

	
	if(movieQuery === undefined) {
		movieQuery = "lion-king"; //default
	}

	// HTTP GET request
	request("http://www.omdbapi.com/?t=" + movieQuery + "&y=&plot=short&r=json", function(error, response, body) {
	  if (!error && response.statusCode === 200) {
        console.log(" Title:         " + JSON.parse(body).Title);
	    console.log(" Year:    " + JSON.parse(body).Year);
	    console.log(" Story:          " + JSON.parse(body).Plot);
        console.log(" Actors:        " + JSON.parse(body).Actors);
        console.log(" Rating:   " + JSON.parse(body).imdbRating);

	    for(let x = 0; x < JSON.parse(body).Ratings.length; x++) {
	    	if(JSON.parse(body).Ratings[x].Source === "Rotten Tomatoes") {
	    		console.log("* Rotten Tomatoes Rating:     " + JSON.parse(body).Ratings[x].Value);
	    		if(JSON.parse(body).Ratings[i].Website !== undefined) {
	    		}
	    	}
	    }
	  }
	});
}

if(action === "spotify-song") {
	spotifyThisSong(query);
} else if(action === "search-movie") {
	movieThis(query);
} else if(action === "do-what-it-says") {
	// App functionality
	let fs = require("fs");

	fs.readFile("blank.txt", "utf-8", function(error, data) {
		let action;
		let query;

		//read actions.
		if(action === "spotify-song") {
			spotifyThisSong(query);
		} else if(action === "search-movie") {
			movieThis(query);
		} else { // Use case where the action is not recognized
			console.log("action from file is not a valid action! Please try again.")
		}
	});

}