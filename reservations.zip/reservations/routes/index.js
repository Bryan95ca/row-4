const express = require('express');
const router = express.Router();
const mongodb = require('mongodb');
 
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


 
router.get('/userlist', function(req, res){
//mongo db server
  const MongoClient = mongodb.MongoClient;

  const url = 'mongodb://localhost:27017/shopsite';
 
  // Connect to the server
  MongoClient.connect(url, function (err, db) {
  if (err) {
    console.log('Unable to connect..', err);
  } else {
    // We are connected
    console.log('Connection established..', url);
 
    // Get collection in DB
    const collection = db.collection('employee');
 
    // Find Employee
    collection.find({}).toArray(function (err, result) {
      if (err) {
        res.send(err);
      } else if (result.length) {
        res.render('userlist',{
 
          // Return to Jade..
          "userlist" : result
        });
      } else {
        res.send('No documents found');
      }

      db.close();
    });
  }
  });
});

router.get('/newuser', function(req, res){
    res.render('newuser', {title: 'new user' });
});
 
router.post('/userlist', function(req, res){
 
    // Mongo Client
    const MongoClient = mongodb.MongoClient;
 
    // MongoDB host
    const url = 'mongodb://localhost:27017/shopsite';
 
    // Connection
    MongoClient.connect(url, function(err, db){
      if (err) {
        console.log('Server: Error:', err);
      } else {
        console.log('Server: Connected!');
 
        // document of collection
        const collection = db.collection('employee');
 
        let user = {user: req.body.user, street: req.body.street,
          city: req.body.city, state: req.body.state, sex: req.body.sex,
          email: req.body.email};
        //insert 
        collection.insert([user], function (err, result){
          if (err) {
            console.log(err);
          } else {
          //redirects back to url: /employee
            res.redirect("userlist");
          }
        });
 
      }
    });
 
  });
 
//Choices...
  router.get('/choices', function(req, res){
    res.render('choices', {title: 'choices' });
});
 
router.post('/choiceslist', function(req, res){
 
    // Mongo Client
    const MongoClient = mongodb.MongoClient;
 
    // MongoDB host
    const url = 'mongodb://localhost:27017/shopsite';
 
    // Connection
    MongoClient.connect(url, function(err, db){
      if (err) {
        console.log('Server: Error:', err);
      } else {
        console.log('Server: Connected!');
 
        // document of collection
        const collection = db.collection('employee');
 
        //insert 
        collection.insert([user], function (err, result){
          if (err) {
            console.log(err);
          } else {
          //redirects back to url: /employee
            res.redirect("newuser");
          }
 
          db.close();
        });
 
      }
    });
 
  });
module.exports = router;