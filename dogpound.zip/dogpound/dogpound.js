

const ctx = document.getElementById("ctx").getContext("2d");
ctx.font = '30px Arial';
 

 //height & Width Control
const HEIGHT = 500;
const WIDTH = 500;
let timeWhenGameStarted = Date.now();   //return time in ms

//score keeper
let score = 0;

 //Enemy spawner
let frameCount = 0;

let bathroom = 0;

let food = 0;

//Player Creation
const player = {
        x:50,
        spdX:30,
        y:40,
        spdY:5,
        name:'dog',
        hp:10,
        width:20,
        height:20,
        color:'brown',
        //move
        pressingDown:false,
        pressingUp:false,
        pressingLeft:false,
        pressingRight:false,
        //
        atkSpd: 1,
        attackCounter:0,
        aimAngle:0,
};
//object lists

let enemyList = {};

let upgradeList = {};

let bathroomList = {};

let foodList = {};

let bulletList = {};

//rng list
rngUpgrade= function(){

    let x = Math.random()*WIDTH;
    let y = Math.random()*HEIGHT;
    let height = 10 
    let width = 10 
    let id = Math.random();
    let spdX = 0;
    let spdY = 0;
    Upgrade(id,x,y,spdX,spdY,width,height);    
}


rngBathroom = function(){

    let x = Math.random()*WIDTH;
    let y = Math.random()*HEIGHT;
    let height = 10 
    let width = 10 
    let id = Math.random();
    let spdX = 0;
    let spdY = 0;
    Bathroom(id,x,y,spdX,spdY,width,height);
   
}

rngFood= function(){

    let x = Math.random()*WIDTH;
    let y = Math.random()*HEIGHT;
    let height = 10 
    let width = 10 
    let id = Math.random();
    let spdX = 0;
    let spdY = 0;
    Food(id,x,y,spdX,spdY,width,height);

}
Bullet = function (id,x,y,spdX,spdY,width,height){
        let bull = {
                x:x,
                spdX:spdX,
                y:y,
                spdY:spdY,
                name:'E',
                id:id,
                width:width,
                height:height,
                color:'black',
                //
                timer:0,
        };
        bulletList[id] = bull;
}

randomlyGenerateBullet = function(actor,aimOverwrite){
        //Math.random() returns a number between 0 and 1
        let x = player.x;
        let y = player.y;
        let height = 10;
        let width = 10;
        let id = Math.random();
       
        let angle;
        if(aimOverwrite !== undefined)
                angle = aimOverwrite;
        else angle = actor.aimAngle;
       
        let spdX = Math.cos(angle/180*Math.PI)*5;
        let spdY = Math.sin(angle/180*Math.PI)*5;
        Bullet(id,x,y,spdX,spdY,width,height);
}


 
//Distance between obj 
getDistanceBetweenEntity = function (entity1,entity2){  //return distance (number)
        let bx = entity1.x - entity2.x;
        let by = entity1.y - entity2.y;
        return Math.sqrt(bx*bx+by*by);
}

//Collision Detector 
testCollisionEntity = function (entity1,entity2){    //if collides return...
        let rect1 = {
                x:entity1.x-entity1.width/2,
                y:entity1.y-entity1.height/2,
                width:entity1.width,
                height:entity1.height,
        }
        let rect2 = {
                x:entity2.x-entity2.width/2,
                y:entity2.y-entity2.height/2,
                width:entity2.width,
                height:entity2.height,
        }
        return testCollisionRectRect(rect1,rect2);
       
}
//the list
Enemy = function (id,x,y,spdX,spdY,width,height,name){
        let enemy = {
            x:x,
            spdX:spdX,
            y:y,
            spdY:spdY,
            name: name,
            id:id,
            width:width,
            height:height,
            color:'red', //Dog Pound
        };
        enemyList[id] = enemy;   
}

Upgrade = function (id,x,y,spdX,spdY,width,height,name){
        let upper = {
            x:x,
            spdX:spdX,
            y:y,
            spdY:spdY,
            name: name,
            id:id,
            width:width,
            height:height,
            color:'orange', //food, points .. doggie bones
        };
        upgradeList[id] = upper;
       
}


Bathroom = function (id,x,y,spdX,spdY,width,height,name){
    let boothroom = {
            x:x,
            spdX:spdX,
            y:y,
            spdY:spdY,
            name: name,
            id:id,
            width:width,
            height:height,
            color:'blue',
    };
    bathroomList[id] = boothroom;
   
}

Food = function (id,x,y,spdX,spdY,width,height,name){
    let health = {
            x:x,
            spdX:spdX,
            y:y,
            spdY:spdY,
            name: name,
            id:id,
            width:width,
            height:height,
            color:'pink',
    };
    foodList[id] = health;
   
}
 
//drawing fucntions --
updateEntity = function (yid){
        updateEntityPosition(yid);
        drawEntity(yid);
}
updateEntityPosition = function(yid){
        yid.x += yid.spdX;
        yid.y += yid.spdY;
                       
        if(yid.x < 0 || yid.x > WIDTH){
                yid.spdX = -yid.spdX;
        }
        if(yid.y < 0 || yid.y > HEIGHT){
                yid.spdY = -yid.spdY;
        }
}
 
testCollisionRectRect = function(rect1,rect2){
        return rect1.x <= rect2.x+rect2.width
                && rect2.x <= rect1.x+rect1.width
                && rect1.y <= rect2.y + rect2.height
                && rect2.y <= rect1.y + rect1.height;
}
 
 //Entity Skeleton
drawEntity = function(yid){
        ctx.save();
        ctx.fillStyle = yid.color;
        ctx.fillRect(yid.x-yid.width/2,yid.y-yid.height/2,yid.width,yid.height);
        ctx.restore();
}

 
document.onclick = function(mouse){
        if(player.attackCounter > 25){  //every 1 sec
                player.attackCounter = 0;
                randomlyGenerateBullet(player);
        }
}
document.oncontextmenu = function(mouse){
        if(player.attackCounter > 50){  //every 1 sec
                player.attackCounter = 0;
                /*
                for(let i = 0 ; i < 360; i++){
                        randomlyGenerateBullet(player,i);
                }
                */
                randomlyGenerateBullet(player,player.aimAngle - 5);
                randomlyGenerateBullet(player,player.aimAngle);
                randomlyGenerateBullet(player,player.aimAngle + 5);
        }
        mouse.preventDefault();
}
 
document.onmousemove = function(mouse){
        let mouseX = mouse.clientX - document.getElementById('ctx').getBoundingClientRect().left;
        let mouseY = mouse.clientY - document.getElementById('ctx').getBoundingClientRect().top;
       
        mouseX -= player.x;
        mouseY -= player.y;
       
        player.aimAngle = Math.atan2(mouseY,mouseX) / Math.PI * 180;
}
 

document.onkeydown = function(event){
        if(event.keyCode === 68)        //d
                player.pressingRight = true;
        else if(event.keyCode === 83)   //s
                player.pressingDown = true;
        else if(event.keyCode === 65) //a
                player.pressingLeft = true;
        else if(event.keyCode === 87) // w
                player.pressingUp = true;
}
 
document.onkeyup = function(event){
        if(event.keyCode === 68)        //d
                player.pressingRight = false;
        else if(event.keyCode === 83)   //s
                player.pressingDown = false;
        else if(event.keyCode === 65) //a
                player.pressingLeft = false;
        else if(event.keyCode === 87) // w
                player.pressingUp = false;
}
 
updatePlayerPosition = function(){
        if(player.pressingRight)
                player.x += 10;
        if(player.pressingLeft)
                player.x -= 10;
        if(player.pressingDown)
                player.y += 10;
        if(player.pressingUp)
                player.y -= 10;

        //ispositionvalid
        if(player.x < player.width/2)
                player.x = player.width/2;
        if(player.x > WIDTH-player.width/2)
                player.x = WIDTH - player.width/2;
        if(player.y < player.height/2)
                player.y = player.height/2;
        if(player.y > HEIGHT - player.height/2)
                player.y = HEIGHT - player.height/2;


}
 
//Health--Respawn--StartGame. 
update = function(){
        ctx.clearRect(0,0,WIDTH,HEIGHT);
        frameCount++;
        score++;
        bathroom++;      

        //creation and spawn.
        if(frameCount % 100 === 0)      //every 4 sec
                rngEnemy();

        if(frameCount % 75 === 0)      //every 3 sec
                rngUpgrade();

        if(frameCount % 35 === 0)      //every 3 sec
                rngBathroom();

        if(frameCount % 180 === 0)      
                rngFood();

                player.attackCounter += player.atkSpd;

                for(let key in bulletList){
                        updateEntity(bulletList[key]);
                       
                        let toRemove = false;
                        bulletList[key].timer++;
                        if(bulletList[key].timer > 75){
                                toRemove = true;
                        }
                       
                        for(let key2 in enemyList){
                                let isColliding = testCollisionEntity(bulletList[key],enemyList[key2]);
                                if(isColliding){
                                        toRemove = true;
                                        delete enemyList[key2];
                                        break;
                                }                      
                        }
                        if(toRemove){
                                delete bulletList[key];
                        }
                }
               
                for(let key in upgradeList){
                        updateEntity(upgradeList[key]);
                        let isColliding = testCollisionEntity(player,upgradeList[key]);
                        if(isColliding){
                                if(upgradeList[key].category === 'score')
                                        score += 1000;
                                if(upgradeList[key].category === 'atkSpd')
                                        player.atkSpd += 3;
                                delete upgradeList[key];
                        }
                }
               
      
            
        //draw obj.

        for(let key in upgradeList){ //loop through upgrade list
                updateEntity(upgradeList[key]); //draws out the upgrade loop
                let isColliding = testCollisionEntity(player,upgradeList[key]);
                if(isColliding) {
                score += 500;
                delete upgradeList[key]
        }
}
        for(let key in foodList){ //loop through enemy list
                updateEntity(foodList[key]); //draws out the enemy loop  
                let isColliding = testCollisionEntity(player,foodList[key]);
                if(isColliding){
                player.hp = player.hp + 1;
                delete foodList[key]
    }
        }
        for(let key in bathroomList){ //loop through upgrade list
                updateEntity(bathroomList[key]); //draws out the upgrade loop             
                let isColliding = testCollisionEntity(player,bathroomList[key]);
                if(isColliding) {
                bathroom -= 20;
                score += 20;
                delete bathroomList[key]
        }
        if(bathroom == 500) {
            startNewGame()
        }
}
               
        for(let key in enemyList){ //loop through enemy list
                updateEntity(enemyList[key]); //draws out the enemy loop  
                let isColliding = testCollisionEntity(player,enemyList[key]);
                if(isColliding){
                player.hp = player.hp - 1;
                }
        }
        if(player.hp <= 0){
                let timeSurvived = Date.now() - timeWhenGameStarted;           
                console.log("You loser! You survived for " + timeSurvived + " ms. with a score of " + score);            
                startNewGame();
        }

        //print score       
        updatePlayerPosition();   
        drawEntity(player);
        ctx.fillText("Health " + player.hp,0,30);
        ctx.fillText("Bladder " + bathroom,180,30);
        ctx.fillText("Score " + score, 0,480);

} //start game after you die. -- respawn.
startNewGame = function(){
        player.hp = 10;
        timeWhenGameStarted = Date.now();
        frameCount = 0;
        enemyList = {};
        bathroomList = {};
        foodList = {};
        upgradeList = {} //delete everything on restart.
        score = 0;
        bathroom = 0;
        rngEnemy();
        rngEnemy();
        rngEnemy();      
}
//enemy creation.
rngEnemy = function(){
        //Math.random() returns a number between 0 and 1
        let x = Math.random()*WIDTH;
        let y = Math.random()*HEIGHT;
        let height = 10 + Math.random()*30;     //between 10 and 40
        let width = 10 + Math.random()*30;
        let id = Math.random();
        let spdX = 5 + Math.random() * 5;
        let spdY = 5 + Math.random() * 5;
        Enemy(id,x,y,spdX,spdY,width,height);     
}
startNewGame();
 //24fps -- 40 ... 20ms refresh rate
setInterval(update,20);