My first game but re-created. Faster Frames and More things to do!

Move around with keys and shoot with mouse.

You can right click and shoot 3 bullets.

Avoid the Red. Grab everything everything else and make sure your bladder doesn't max out at 500!

Check your score in the Console.

Enjoy!