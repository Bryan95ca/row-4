const ctx = document.getElementById("ctx").getContext("2d");
ctx.font = '30px Arial';
 

 //height & Width Control
let HEIGHT = 500;
let WIDTH = 500;
let timeWhenGameStarted = Date.now();   //return time in ms

//score keeper
let score = 0;

 //Enemy spawner
let frameCount = 0;


let food = 0;

//Creation
let player = {
        x:50,
        spdX:30,
        y:40,
        spdY:5,
        name:'P',
        hp:10,
        width:20,
        height:20,
        color:'green',
};

let enemyList = {};

let upgradeList = {};



let foodList = {};

rngUpgrade= function(){
        //Math.random() returns a number between 0 and 1
        let x = Math.random()*WIDTH;
        let y = Math.random()*HEIGHT;
        let height = 10 
        let width = 10 
        let id = Math.random();
        let spdX = 0;
        let spdY = 0;
        Upgrade(id,x,y,spdX,spdY,width,height);
       
}

rngFood= function(){
    //Math.random() returns a number between 0 and 1
    let x = Math.random()*WIDTH;
    let y = Math.random()*HEIGHT;
    let height = 10 
    let width = 10 
    let id = Math.random();
    let spdX = 0;
    let spdY = 0;
    Food(id,x,y,spdX,spdY,width,height);
}

 
//Distance between obj 
getDistanceBetweenEntity = function (entity1,entity2){  //return distance (number)
        let bx = entity1.x - entity2.x;
        let by = entity1.y - entity2.y;
        return Math.sqrt(bx*bx+by*by);
}

//Collision Detector 
testCollisionEntity = function (entity1,entity2){    //if collides return...
        let rect1 = {
                x:entity1.x-entity1.width/2,
                y:entity1.y-entity1.height/2,
                width:entity1.width,
                height:entity1.height,
        }
        let rect2 = {
                x:entity2.x-entity2.width/2,
                y:entity2.y-entity2.height/2,
                width:entity2.width,
                height:entity2.height,
        }
        return testCollisionRectRect(rect1,rect2);
       
}

//Enemy skeleton
Enemy = function (id,x,y,spdX,spdY,width,height,name){
        let enemy = {
                x:x,
                spdX:spdX,
                y:y,
                spdY:spdY,
                name: name,
                id:id,
                width:width,
                height:height,
                color:'red',
        };
        enemyList[id] = enemy;
       
}

Upgrade = function (id,x,y,spdX,spdY,width,height,name){
        let upper = {
                x:x,
                spdX:spdX,
                y:y,
                spdY:spdY,
                name: name,
                id:id,
                width:width,
                height:height,
                color:'orange',
        };
        upgradeList[id] = upper;
       
}


Food = function (id,x,y,spdX,spdY,width,height,name){
    let health = {
            x:x,
            spdX:spdX,
            y:y,
            spdY:spdY,
            name: name,
            id:id,
            width:width,
            height:height,
            color:'pink',
    };
    foodList[id] = health;
   
}
 
//Mouse Dead Zone and Mouse position ON obj.
//player movement
document.onmousemove = function(mouse){
        let mouseX = mouse.clientX - document.getElementById('ctx').getBoundingClientRect().left;
        let mouseY = mouse.clientY - document.getElementById('ctx').getBoundingClientRect().top;
       
       //dead-zone
        if(mouseX < player.width/2)
                mouseX = player.width/2;
        if(mouseX > WIDTH-player.width/2)
                mouseX = WIDTH - player.width/2;
        if(mouseY < player.height/2)
                mouseY = player.height/2;
        if(mouseY > HEIGHT - player.height/2)
                mouseY = HEIGHT - player.height/2;
       
        player.x = mouseX;
        player.y = mouseY;
}
 
 
 
//drawing fucntions --
updateEntity = function (yid){
        updateEntityPosition(yid);
        drawEntity(yid);
}
updateEntityPosition = function(yid){
        yid.x += yid.spdX;
        yid.y += yid.spdY;
                       
        if(yid.x < 0 || yid.x > WIDTH){
                yid.spdX = -yid.spdX;
        }
        if(yid.y < 0 || yid.y > HEIGHT){
                yid.spdY = -yid.spdY;
        }
}
 
testCollisionRectRect = function(rect1,rect2){
        return rect1.x <= rect2.x+rect2.width
                && rect2.x <= rect1.x+rect1.width
                && rect1.y <= rect2.y + rect2.height
                && rect2.y <= rect1.y + rect1.height;
}
 
 //Entity Skeleton
drawEntity = function(yid){
        ctx.save();
        ctx.fillStyle = yid.color;
        ctx.fillRect(yid.x-yid.width/2,yid.y-yid.height/2,yid.width,yid.height);
        ctx.restore();
}
 
 
//Health--Respawn--StartGame. 
update = function(){
        ctx.clearRect(0,0,WIDTH,HEIGHT);
        frameCount++;
        score++;

        if(frameCount % 100 === 0)      //every 4 sec
                rngEnemy();

        if(frameCount % 75 === 0)      //every 3 sec
                rngUpgrade();


        if(frameCount % 250 === 0)      
                rngFood();
            

        for(let key in upgradeList){ //loop through upgrade list
                updateEntity(upgradeList[key]); //draws out the upgrade loop
                let isColliding = testCollisionEntity(player,upgradeList[key]);
                if(isColliding) {
                score += 1000;
                delete upgradeList[key]
        }
}
        for(let key in foodList){ //loop through enemy list
                updateEntity(foodList[key]); //draws out the enemy loop  
                let isColliding = testCollisionEntity(player,foodList[key]);
                if(isColliding){
                player.hp = player.hp + 1;
                delete foodList[key]
    }
}
 
               
        for(let key in enemyList){ //loop through enemy list
                updateEntity(enemyList[key]); //draws out the enemy loop  
                let isColliding = testCollisionEntity(player,enemyList[key]);
                if(isColliding){
                player.hp = player.hp - 1;
                }
        }
        if(player.hp <= 0){
                let timeSurvived = Date.now() - timeWhenGameStarted;           
                console.log("You lost! You survived for " + timeSurvived + " ms. with a score of " + score);            
                startNewGame();
        }
                       
        drawEntity(player);
        ctx.fillText("Health " + player.hp,0,30);
        ctx.fillText("Score " + score, 0,400);

} //start game after you die.
startNewGame = function(){
        player.hp = 10;
        timeWhenGameStarted = Date.now();
        frameCount = 0;
        enemyList = {};
        upgradeList = {} //delete everything on restart.
        score = 0;
        rngEnemy();
        rngEnemy();
        rngEnemy();
       
}
 
//enemy creation.
rngEnemy = function(){
        //Math.random() returns a number between 0 and 1
        let x = Math.random()*WIDTH;
        let y = Math.random()*HEIGHT;
        let height = 10 + Math.random()*30;     //between 10 and 40
        let width = 10 + Math.random()*30;
        let id = Math.random();
        let spdX = 5 + Math.random() * 5;
        let spdY = 5 + Math.random() * 5;
        Enemy(id,x,y,spdX,spdY,width,height);
       
}
 
startNewGame();
 
setInterval(update,40);