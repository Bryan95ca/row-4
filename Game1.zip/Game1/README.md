a game where you move your mouse around and avoid the red rectangles.

Collect Orange Squares to gain points.

Collect Pink Squares to Gain HP.

Open your console to check your score!